 
const form = document.getElementById("form");
const email = document.getElementById("email");
const firstName = document.getElementById("fname");
const lastName = document.getElementById("lname");

function checkValidation() {
  const inputEmail = email.value.trim();
  const inputPassword = password.value.trim();
  const inputFName = firstName.value.trim();
  const inputLName = lastName.value.trim();


  // Email
  if (inputEmail === null || inputEmail === "") {
    document.querySelector(".errorEmail").style.display = "block";
    return false;
  } else {
    document.querySelector(".errorEmail").style.display = "none";

  }
  
  // Password
  if (inputPassword === null || inputPassword === "") {
    document.querySelector(".errorPassword").style.display = "block";
    return false;
  } else {
    document.querySelector(".errorPassword").style.display = "none";
  }
  
  // First Name
  if (inputFName === null || inputFName === "") {
    document.querySelector(".errorFname").style.display = "block";
    return false;
  } else {
    document.querySelector(".errorFname").style.display = "none";
  }

  // Last Name
  if (inputLName === null || inputLName === "") {
    document.querySelector(".errorLname").style.display = "block";
    return false;
  } else {
    document.querySelector(".errorLname").style.display = "none";
  }

  return true;
}
