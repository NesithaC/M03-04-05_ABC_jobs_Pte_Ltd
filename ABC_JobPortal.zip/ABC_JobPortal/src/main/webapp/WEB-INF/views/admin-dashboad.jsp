<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
	<%@ page isELIgnored="false" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="css/header.css" rel="stylesheet" type="text/css">
<link href="css/footer.css" rel="stylesheet" type="text/css">
<link href="css/admin-dashboad.css" rel="stylesheet" type="text/css">
<title>Admin dashboad</title>
</head>
<body>
<%@ include file="header.jsp" %>

	<h1 align="center">Admin Dashboard</h1>

	<div class="container-fluid">
		
			<div class="row">
				
			    <div class="col-md-6" id="con_left">
				    
				    <h3 id="search_note">Search Users</h3>
				   	<form method="get" class="example" action="search">
					  <input type="text" id="search_bar" name="keyword"/> &nbsp;
					  <button type="submit" value="Search" id="search_button"><i class="fa fa-search"></i></button>
					</form>
			    </div>
			    
			    <div class="col-md-6 my-4" id="con_right">
			    	<a href="<%= request.getContextPath() %>/send-bulk-email" class="bulk_email_button">
						Send Bulk Email
					</a>
			    </div>
			    
			</div>
	</div>
	
	<h3 align="center">Users Data</h3>
	<div align="center">
		<table class="table">
		<thead>
			<tr>
				<th>User ID</th>
				<th>First name</th>
				<th>Last name</th>
				<th>E-mail</th>
				<th>Phone number</th>
				<th>Country</th>
				<th>City</th>
				<th>Company name</th>
				<th>Qualification</th>
				<th>Career path</th>
				<th>Action</th>
			</tr>
			</thead>
			<c:forEach items="${allStore}" var="user">
			<tbody>
			<tr>
				<td>${user.userID}</td>
				<td>${user.firstName}</td>
				<td>${user.lastName}</td>
				<td>${user.email}</td>
				<td>${user.phonenumber}</td>
				<td>${user.country}</td>
				<td>${user.city}</td>
				<td>${user.companyname}</td>
				<td>${user.qualification}</td>
				<td>${user.careerpath}</td>
				<td>
					<a class="td_button" href="adminedituser/${user.userID}">Edit</a>
					&nbsp;&nbsp;&nbsp;<a class="td_button" href="delete?id=${user.userID}">Delete</a>
				</td>
			</tr>
			</tbody>
			</c:forEach>
		</table>
	</div>	

			<%@ include file="footer.jsp" %>
		<script  type="text/javascript" src="../js/loginvalidation.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>