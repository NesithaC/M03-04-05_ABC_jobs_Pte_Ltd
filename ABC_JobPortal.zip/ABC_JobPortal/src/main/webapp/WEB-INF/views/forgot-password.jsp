<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Log in</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
	    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<link href="css/header.css" rel="stylesheet" type="text/css">
		<link href="css/footer.css" rel="stylesheet" type="text/css">
		<link href="css/forgot-password.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<%@ include file="header.jsp" %>

	<div class="container-fluid">
		<div class="row" >
				
		    <div class="col-md-6" id="con_left">
		    	<img class="forgotpass_img" alt="forgot password image" src="img/recruit-agent-analyzing-candidates_74855-4565.jpg">
		    </div>
		    	
		    <div class="col-md-6" id="con_right">
		    	<h3>Forgot Password</h3>
		    	
		    	<h5 id="forgot_note">Enter your email that used to register</h5>
		    	<form name="forgot_email_form" action="email-check" class="needs-validation" novalidate>
				    
				    <div class="form-group">
				      <label for="email">Email:</label>
				      <input type="email" class="form-control" id="email" name="email" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field. Required '@' for email.</div>
				    </div>
				    
				    <button type="submit" class="forgot_password_button">Next</button>
				  </form>		    	
		    </div>
		    	   
  		</div>
  	</div>

	<%@ include file="footer.jsp" %>
	<script  type="text/javascript" src="js/forgot-password.js"></script>
	</body>
</html>