<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<p id="copy_text">Copyright2022&copy;ABCJobs(pvt)Ltd. All right reserved.</p>