<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
     <%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>       
    <%@ page isELIgnored="false" %>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="UTF-8">
	<title>Admin user edit</title>
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<link href="../css/header.css" rel="stylesheet" type="text/css">
		<link href="../css/footer.css" rel="stylesheet" type="text/css">
		<link href="../css/admin-user-edit.css" rel="stylesheet" type="text/css">
	</head>
<body>
	
	<%@ include file="header-edit.jsp" %>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3" id="con_left">
		    		    	
		    </div>
		    	
		    <div class="col-md-6" id="con_middle">
		    	<h3>Admin Edit User Profile</h3>
		    	<form method="post" name="reg_form" id="editProfile" action="../admin-dashboad" class="needs-validation" modelAttribute="user" novalidate>
		    	<!--  -->
		    	<%-- <c:forEach var="user" items="${allStore}"> --%>
		    	
		    		<div class="mb-3">
						<input value="${user.userID}" name="userID" id="userID" hidden="hidden"/>
					</div>
				    <div class="form-group">
				      <label for="exampleFormControlInput1">First name:</label>
				      <input type="text" value="${user.firstName}" class="form-control" name="firstName" id="firstName" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    
				    <div class="form-group">
				      <label for="exampleFormControlInput1">Last name:</label>
				      <input type="text" value="${user.lastName}" class="form-control" name="lastName" id="lastName" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    
				    <div class="form-group">
				      <label for="exampleFormControlInput1">Email:</label>
				      <input type="email" value="${user.email}" class="form-control" id="email" name="email" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field. Required '@' for email.</div>
				    </div>
				    
				    <!--<div class="form-group">
				      <label for="password">Password:</label>
				      <input type="password" value="${user.pass}" class="form-control" id="password" name="pass" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>  -->
				    
				    <div class="form-group">
				      <label for="phonenumber">Phone number:</label>
				      <input type="text" value="${user.phonenumber}" class="form-control" id="phonenumber" name="phonenumber" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				      <span id="passwordlocation" style="color:red"></span>
				    </div>
				    
				    <div class="form-group">
				      <label for="country">Country:</label>
				      <input type="text" value="${user.country}" class="form-control" id="country" name="country">
				    </div>
				    
				    <div class="form-group">
				      <label for="city">City:</label>
				      <input type="text" value="${user.city}" class="form-control" id="city" name="city">
				    </div>
				    
				    <div class="form-group">
				      <label for="companyname">Company name:</label>
				      <input type="text" value="${user.companyname}" class="form-control" id="companyname" name="companyname">
				    </div>
				    
				    <div class="form-group">
				      <label for="qualification">Qualification:</label>
				      <input type="text" value="${user.qualification}" class="form-control" id="qualification" name="qualification">
				    </div>
				    
				    <div class="form-group">
				      <label for="careerpath">Career path:</label>
				      <input type="text" value="${user.careerpath}" class="form-control" id="careerpath" name="careerpath">
				    </div>
				    <button type="submit" id="update" name="update" class="update_button">Update Profile</button>
				    <a id="admin_link" href="../admin-dashboad">Go Back</a>
				  <%-- </c:forEach> --%>
				  
				  </form>	
				  
		    </div>
		    	
		    <div class="col-md-3" id="con_right">
		    		    	
		    </div>
		    	   
  		</div>
  	</div>

	<%@ include file="footer-edit.jsp" %>
	<script  type="text/javascript" src="../js/loginvalidation.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    
   

</body>
</html>