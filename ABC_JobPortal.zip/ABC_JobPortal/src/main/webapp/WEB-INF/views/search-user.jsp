<%@ page language="java" contentType="text/html; charset=UTF-8" isELIgnored="false"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
	<%@ page isELIgnored="false" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="UTF-8">
	<title>Search user</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	<link href="css/header.css" rel="stylesheet" type="text/css">
	<link href="css/footer.css" rel="stylesheet" type="text/css">
	<link href="css/search-user.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<%@ include file="header.jsp" %>
	
		<div class="container-fluid"  style="margin-bottom: 350px;">
			<div class="row">
					
			    <div class="col-md-3" id="con_right">
			    
			    </div>
			    	
			    <div class="col-md-6" id="con_middle">
			    	<h3 id="search_note">Search Users</h3>
				
					<form method="get" class="example" action="searchuser" style="margin-bottom: 60px;">
					  <input type="text" id="search_bar" name="keyword"/> &nbsp;
					  <button type="submit" value="Search" id="search_button"><i class="fa fa-search"></i></button>
					</form>  
					
					 <c:forEach items="${allStore}" var="user" >
						<tbody>
							<tr style="margin-bottom: 60px; padding: 20px; color: black; background-color: #453CAF;">
								
								<td class="my-5">${user.firstName}</td>
								<td>${user.lastName}</td>
								<td>${user.country}</td>
								<td>
									<a class="profile_link" href="otheruser/${user.userID}">See Profile</a>
									
								</td>
							</tr>
							
						</tbody><br>
						</c:forEach> 	
			    </div>
			    <div class="col-md-3" id="con_left">
			    	<a class="profile_link" href="<%= request.getContextPath() %>/profile">User Profile</a>
			    </div>	   
	  		</div>
  		</div>
				

	<%@ include file="footer.jsp" %>
</body>
</html>