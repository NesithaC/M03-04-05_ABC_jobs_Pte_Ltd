<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Register</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
	    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<link href="css/header.css" rel="stylesheet" type="text/css">
		<link href="css/footer.css" rel="stylesheet" type="text/css">
		<link href="css/register.css" rel="stylesheet" type="text/css">
</head>
<body>
	<%@ include file="header.jsp" %>

	<div class="container-fluid">
		<div class="row" >
				
		    <div class="col-md-6" id="con_left">
		    	<img alt="register image" class="reg_image" src="img/team-leader-teamwork-concept_74855-6671.jpg">
		    </div>
		    	
		    <div class="col-md-6" id="con_right">
		    	<h3>Register</h3>
		    	<form:form method="post" name="reg_form" modelAttribute="user" action="registerProcess" class="needs-validation" novalidate="default namespace">
		    	<!--  -->
				    <div class="form-group">
				      <form:label for="fname" path="firstName" >First name:</form:label>
				      <form:input type="text" class="form-control" path="firstName" id="fname" name="fname"/>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    
				    <div class="form-group">
				      <form:label for="lname" path="lastName">Last name:</form:label>
				      <form:input type="text" class="form-control" path="lastName" id="lname" name="lname"/>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    
				    <div class="form-group">
				      <form:label for="email" path="email">Email:</form:label>
				      <form:input type="email" class="form-control" id="email" path="email" name="email"/>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field. Required '@' for email.</div>
				    </div>
				    
				    <div class="form-group">
				      <form:label for="inputPassword2" path="pass">Password:</form:label>
				      <form:input type="password" class="form-control" path="pass" id="password" name="pass"/>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    
				    <div class="form-group">
				      <form:label for="phonenumber" path="phonenumber">Phone number:</form:label>
				      <form:input type="text" class="form-control" path="phonenumber" id="phonenumber" name="phonenumber"/>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				      <span id="passwordlocation" style="color:red"></span>
				    </div>
				    
				    <div class="form-group form-check">
				      <label class="form-check-label">
				        <input class="form-check-input" type="checkbox" name="remember" required>I agree on terms and conditions.
				        <div class="valid-feedback">Valid.</div>
				        <div class="invalid-feedback">Check this checkbox to continue.</div>
				      </label>
				    </div>
				    
				    <button type="submit" class="submit_button">Submit</button>
				    <a id="login_link" href="<%= request.getContextPath() %>/login">You already have account</a>
				  </form:form>	
				 
		    </div>
		    	   
  		</div>
  	</div>
	<footer>
		<%@ include file="footer.jsp" %>
	</footer>
	<script type="text/javascript" src="js/registervalidation.js"></script>	
	<script type="text/javascript" src="js/validation.js"></script>	
</body>
</html>