<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>       
    <%@ page isELIgnored="false" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Bulk Email</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bulk-email.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link href="css/header.css" rel="stylesheet" type="text/css">
<link href="css/footer.css" rel="stylesheet" type="text/css">
</head>
<body>

<%@ include file="header.jsp" %>
     
        <div class="container-fluid">
		
			<div class="row">
				
			    <div class="col-md-3" id="con_left">
			    </div>
			    
				    <div class="col-md-6" id="con_middle">
				    	 <h1 class="my-5 headingone">Administration System</h1>
	        
	      
	    
	
					    
				
				    <!-- Page content -->
				    
				
				      <div class="content-edit my-3">
				        <form:form action="sendBulkEmail" method="post" modelAttribute="bulk-email" id="form">
				          
				            
				             
				                <div class="heading">
				                  <h2 class="my-4">Send Bulk Email</h2>
				                </div>
				
				                <!-- hidden -->
				                <div class="form-group">
				                  <form:hidden path="id_bulk_email" class="form-control" />
				                </div>
				
				                <!-- Subject -->
				                <div class="form-group">
				                  <label for="subject">Subject</label>
				                  <form:input path="subject" type="text"  class="form-control" />
				                </div>
				
				                <!-- Body -->
				                <div class="form-group">
				                  <label for="content">Content</label>
				                  <form:textarea path="content" class="form-control" />
				                </div>
				
				                <button type="submit" class="send_button my-4">Send Email</button>
				          		<a class="admin_button my-4" href="<%= request.getContextPath() %>/admin-dashboad">Go Back</a>
				        </form:form>
				       
				      </div>
				       
			    </div>
			    
			    <div class="col-md-3" id="con_right">
			    </div>
			</div>
		</div>
          
   <%@ include file="footer.jsp" %>      


</body>
</html>