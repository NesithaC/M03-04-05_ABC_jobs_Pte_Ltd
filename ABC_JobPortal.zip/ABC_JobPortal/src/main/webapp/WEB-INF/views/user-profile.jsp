<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>user profile</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	<link href="css/header.css" rel="stylesheet" type="text/css">
	<link href="css/footer.css" rel="stylesheet" type="text/css">
	<link href="css/user-profile.css" rel="stylesheet" type="text/css">
</head>
	<body>
		<%@ include file="header.jsp" %>
		
		<div class="container-fluid">
		
			<div class="row">
				
			    <div class="col-md-6" id="con_left">
			    	<img class="user_profile_main_img" alt="profile main image" src="img/recruiting-professionals-studying-candidate-profiles_1262-21404.jpg">
			    </div>
			    	
			    <div class="col-md-6" id="con_right">
			    	<div class="button_bar">
						<a class="user_profile_button" href="<%= request.getContextPath() %>/profile-edit/${user.userID}">Edit Profile</a>
						<a class="search_users_button" href="<%= request.getContextPath() %>/search-user">Search Others</a>
						<a class="search_users_button" href="<%= request.getContextPath() %>/logout">Logout</a>
					</div>
			    	<h3>Profile</h3>
			    	<img class="user_profile_img" alt="user profile image" src="img/user-one.jpg">
			    	
			    	<div class="form-group">
				      <label for="name">Name:</label>
				     	<p id="user_data">${user.firstName} ${user.lastName}</p> 
				    </div>
			    	 <div class="form-group">
				      <label for="email">Email:</label>
				     	<p id="user_data">${user.email}</p> 
				    </div>
				    <div class="form-group">
				      <label for="phone-number">Phone number:</label>
				     	<p id="user_data">${user.phonenumber}</p> 
				    </div>
				    <div class="form-group">
				      <label for="country">Country:</label>
				     	<p id="user_data">${user.country}</p> 
				    </div>
				    <div class="form-group">
				      <label for="city">City:</label>
				     	<p id="user_data">${user.city}</p> 
				    </div>	
				    <div class="form-group">
				      <label for="company-name">Company name:</label>
				     	<p id="user_data">${user.companyname}</p> 
				    </div>  
				    <div class="form-group">
				      <label for="qulification">Qualification:</label>
				     	<p id="user_data">${user.qualification}</p> 
				    </div>  
				    <div class="form-group">
				      <label for="career-path">Career path:</label>
				     	<p id="user_data">${user.careerpath}</p> 
				    </div>	
			    </div>
			    	   
	  		</div>
	  	</div>
	
		<%@ include file="footer.jsp" %>
		
	</body>
</html>