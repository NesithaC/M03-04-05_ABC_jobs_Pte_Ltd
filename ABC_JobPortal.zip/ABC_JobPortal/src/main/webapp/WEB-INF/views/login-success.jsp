<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>login success</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	<link href="css/header.css" rel="stylesheet" type="text/css">
	<link href="css/footer.css" rel="stylesheet" type="text/css">
	<link href="css/login-success.css" rel="stylesheet" type="text/css">
</head>
<body>
	<%@ include file="header.jsp" %>

	<div class="container-fluid">
		<div class="row" >
				
		    <div class="col-md-6" id="con_left">
		    	<img alt="image" class="login_success_img" src="img/woman-characters-having-business-conversation-meeting-flat-illustration_74855-14211.jpg">
		    </div>
		    	
		    <div class="col-md-6" id="con_right">
			    	<h3 class="login_success_note"><b>You are successfully logged in.</b></h3>
			    	<a class="login_success_button" href="profile">Next</a>	    	
		    </div>
		    	   
  		</div>
  	</div>

	<%@ include file="footer.jsp" %>
</body>
</html>