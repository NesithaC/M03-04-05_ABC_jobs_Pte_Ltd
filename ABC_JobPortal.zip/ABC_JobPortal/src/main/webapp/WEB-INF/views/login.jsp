<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Log in</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
	    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<link href="css/header.css" rel="stylesheet" type="text/css">
		<link href="css/footer.css" rel="stylesheet" type="text/css">
		<link href="css/login.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<%@ include file="header.jsp" %>

	<div class="container-fluid">
		<div class="row" >
				
		    <div class="col-md-6" id="con_left">
		    	<img class="login_img" alt="login image" src="img/recruit-agent-analyzing-candidates_74855-4565.jpg">
		    </div>
		    	
		    <div class="col-md-6" id="con_right">
		    	<h3>Log in</h3>
		    	<form:form method="post" id="loginForm" modelAttribute="loginDto" name="login_form" action="check" class="needs-validation" novalidatexmlns="default namespace">
				    
				    <div class="form-group">
				      <form:label for="inputEmail" path="emailId">Email:</form:label>
				      <form:input type="email" path="emailId" class="form-control" id="email" name="email"/>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field. Required '@' for email.</div>
				    </div>
				    
				    <div class="form-group">
				      <form:label for="inputPassword" path="password">Password:</form:label>
				      <form:input type="password"  path="password" class="form-control" id="pass" name="pass"/>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    
				    
				    <a id="link" href="<%= request.getContextPath() %>/forgot-password">Forgot password</a>
				    <a id="link" href="<%= request.getContextPath() %>/register"> or You don't have account</a>
				    <br>
				    <form:button type="submit" id="login" name="login" class="login_button">Login</form:button>
				  </form:form>		    	
		    </div>
		    	   
  		</div>
  	</div>

	<%@ include file="footer.jsp" %>
	<script  type="text/javascript" src="js/loginvalidation.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
	<script type="text/javascript" src="resources/js/validation.js"></script>
	</body>
</html>