<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<nav>
	<div class="container-fluid">
		<div class="row" id="header_row">	
		    <div class="col-md-2"><img id="logo_img" alt="logo" src="../img/ABC jobs original.png"></div>
		    <div class="col-md-4"><h1 id="com_title">ABC Jobs</h1></div>
		    <div class="col-md-6" id="head_nav">
		    	<a class="head_button" href="<%= request.getContextPath() %>/home">Home</a>
		    	<a class="head_button" href="<%= request.getContextPath() %>/login">Log in</a>
		    	<a class="head_button" href="<%= request.getContextPath() %>/register">Register</a>
		    </div>	   
  		</div>
  	</div>	
</nav>