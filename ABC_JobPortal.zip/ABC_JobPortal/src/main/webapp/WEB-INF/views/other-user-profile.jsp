<%@ page language="java" contentType="text/html; charset=UTF-8" isELIgnored="false"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="UTF-8">
	<title>Other User</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	<link href="../css/header.css" rel="stylesheet" type="text/css">
	<link href="../css/footer.css" rel="stylesheet" type="text/css">
	<link href="../css/other-user-one.css" rel="stylesheet" type="text/css">
</head>
<body>
	<%@ include file="header-edit.jsp" %>
		
		<div class="container-fluid">
		
			<div class="row">
				
			    <div class="col-md-6" id="con_left">
			    	<img class="user_profile_main_img" alt="profile main image" src="../img/recruiting-professionals-studying-candidate-profiles_1262-21404.jpg">
			    </div>
			    	
			    <div class="col-md-6" id="con_right">
			    	<div class="button_bar">
						<a class="search_users_button" href="<%= request.getContextPath() %>/search-user">Go Back</a>
					</div>
			    	<h3>Profile</h3>
			    	<img class="user_profile_img" alt="user profile image" src="../img/usertwo.png">
			    	
			    	<div class="form-group">
				      <label for="name">Name:</label>
				     	<p id="user_data">${user.firstName}</p> 
				    </div>
			    	 <div class="form-group">
				      <label for="email">Email:</label>
				     	<p id="user_data">${user.email}</p> 
				    </div>
				    <div class="form-group">
				      <label for="phone-number">Phone number:</label>
				     	<p id="user_data">${user.phonenumber}</p> 
				    </div>
				    <div class="form-group">
				      <label for="country">Country:</label>
				     	<p id="user_data">${user.country}</p> 
				    </div>
				    <div class="form-group">
				      <label for="city">City:</label>
				     	<p id="user_data">${user.city}</p> 
				    </div>	
				    <div class="form-group">
				      <label for="company-name">Company name:</label>
				     	<p id="user_data">${user.companyname}</p> 
				    </div>  
				    <div class="form-group">
				      <label for="qulification">Qualification:</label>
				     	<p id="user_data">${user.qualification}</p> 
				    </div>  
				    <div class="form-group">
				      <label for="career-path">Career path:</label>
				     	<p id="user_data">${user.careerpath}</p> 
				    </div>
				    
			    </div>
			    	   
	  		</div>
	  	</div>
	
		<%@ include file="footer-edit.jsp" %>
		
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>