<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		
		<meta charset="UTF-8">
		<title>home</title>
		
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<link href="css/header.css" rel="stylesheet" type="text/css">
		<link href="css/footer.css" rel="stylesheet" type="text/css">
		<link href="css/home.css" rel="stylesheet" type="text/css">
		
	</head>
	<body>
		<%@ include file="header.jsp" %>
		
		
		<div class="container-fluid">
			<div class="row" style="margin: 0; padding: 0;">
					
			    <div class="col-md-8" id="con_left">
			    	<img class="home_img" alt="image" src="img/we-are-hiring-landing-page-employer-offer-vacant-place-illuminated-with-spotlight-hire-job-announcement-candidates-head-hunting-human-resources-research-recruiting-cartoon-vec.jpg">
			    	<p id="description">Find your Job. We are offerring jobs in all arround the world. Join with us today and start to search your journey with Global Companies.</p>
			    </div>
			    	
			    <div class="col-md-4">
			    	<div id="con_right">
			    		<h5 id="note">Join with us<br>today.</h5>
			    		<a class="reg_button" href="<%= request.getContextPath() %>/register">Register</a>
			    	</div>	    	
			    </div>	   
	  		</div>
  		</div>	
		<
		<footer>
			<%@ include file="footer.jsp" %>
		</footer>
	</body>
</html>