<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Search result</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	<link href="css/header.css" rel="stylesheet" type="text/css">
	<link href="css/footer.css" rel="stylesheet" type="text/css">
	<link href="css/search-result.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<%@ include file="header.jsp" %>
	
		<div class="container-fluid">
			<div class="row">
					
			    <div class="col-md-3" id="con_left">
			    
			    </div>
			    	
			    <div class="col-md-6" id="con_middle">
			    	<h3 id="search_result_note">Search Result</h3>
			    	
			    	<div id="search_box" class="container-fluid">
			    		<div class="row">
			    			<div class="col-md-4">
			    				<img class="search_profile_img" alt="user image" src="img/usertwo.png">
			    			</div>
			    			<div class="col-md-4">
			    				<p id="result name">Jesper Moody</p>
			    			</div>
			    			<div class="col-md-4">
			    			<a class="search_result" href="<%= request.getContextPath() %>/other-user-one">See Profile</a>
			    			</div>
			    		</div>
			    	</div>
			    	
			    	<div id="search_box" class="container-fluid">
			    		<div class="row">
			    			<div class="col-md-4">
			    				<img class="search_profile_img" alt="user image" src="img/userthree.jpg">
			    			</div>
			    			<div class="col-md-4">
			    				<p id="result name">Sarah Booth</p>
			    			</div>
			    			<div class="col-md-4">
			    			<a class="search_result" href="#">See Profile</a>
			    			</div>
			    		</div>
			    	</div>
			    	
			    	<div id="search_box" class="container-fluid">
			    		<div class="row">
			    			<div class="col-md-4">
			    				<img class="search_profile_img" alt="user image" src="img/userfour.png">
			    			</div>
			    			<div class="col-md-4">
			    				<p id="result name">Tom Goodwin</p>
			    			</div>
			    			<div class="col-md-4">
			    			<a class="search_result" href="#">See Profile</a>
			    			</div>
			    		</div>
			    	</div>
			    	
			    	<div id="search_box" class="container-fluid">
			    		<div class="row">
			    			<div class="col-md-4">
			    				<img class="search_profile_img" alt="user image" src="image/userfive.jpeg">
			    			</div>
			    			<div class="col-md-4">
			    				<p id="result name">Perry Jackson</p>
			    			</div>
			    			<div class="col-md-4">
			    			<a class="search_result" href="#">See Profile</a>
			    			</div>
			    		</div>
			    	</div>
			    	
			    </div>
			    <div class="col-md-3" id="con_right">
			    	<a class="search_link" href="<%= request.getContextPath() %>/search-user">Search Others</a>
			    </div>	   
	  		</div>
  		</div>
				

	<%@ include file="footer.jsp" %>
</body>
</html>