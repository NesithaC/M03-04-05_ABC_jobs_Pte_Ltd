<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Register thank you</title>
		
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<link href="css/header.css" rel="stylesheet" type="text/css">
		<link href="css/footer.css" rel="stylesheet" type="text/css">
		<link href="css/register-thank.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<%@ include file="header.jsp" %>
	
		<div class="container-fluid">
			<div class="row" >
					
			    <div class="col-md-6" id="con_left">
			    	<img alt="register thank image" class="thank_reg_img" src="img/woman-characters-having-business-conversation-meeting-flat-illustration_74855-14211.jpg">
			    </div>
			    	
			    <div class="col-md-6" id="con_right">
			    	<h3 class="thank_note">${email}<br><b>Thank you for join with us.</b></h3>
			    	<a class="login_button" href="<%= request.getContextPath() %>/login">Next</a>	    	
			    </div>
			    	   
	  		</div>
	  	</div>
	
		<%@ include file="footer.jsp" %>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
	</body>
</html>