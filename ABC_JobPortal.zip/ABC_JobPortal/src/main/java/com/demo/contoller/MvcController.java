package com.demo.contoller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MvcController {
	@RequestMapping(value = "/login-success", method = RequestMethod.GET)
	public String loginsuccess()
	{
		return "login-success";
	}
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String home()
	{
		return "home";
	}

	/*@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home()
	{
		return "index";
	}*/

	@GetMapping("/forgot-password")
	public ModelAndView forgotPassword() {
		ModelAndView mv = new ModelAndView("forgot-password");
		return mv;
	}
	
	@GetMapping("/email-check")
	public ModelAndView forgotChangePassword() {
		ModelAndView mv = new ModelAndView("forgot-change-password");
		return mv;
	}
	@GetMapping("/change-password-success")
	public ModelAndView changepasswordsuccess() {
		ModelAndView mv = new ModelAndView("change-password-success");
		return mv;
	}
	
	@GetMapping("/search-user")
	public ModelAndView searchothers() {
		ModelAndView mv = new ModelAndView("search-user");
		return mv;
	}
	@GetMapping("/search-result")
	public ModelAndView searchresult() {
		ModelAndView mv = new ModelAndView("search-result");
		return mv;
	}
	
}
