package com.demo.contoller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.demo.model.User;
import com.demo.service.UserService;

@Controller
public class ProfileController {
	
	@Autowired
	public UserService userService;
	
	/*
	 * controller for see admin profile
	 * get the session and retrieve data from database
	 * */
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public ModelAndView seeProfile(HttpServletRequest request) throws Exception{
		ModelAndView model = new ModelAndView();
        HttpSession session = request.getSession(true);
        Integer userId = (int)session.getAttribute("userId");

        User user = userService.findUserById(userId);

			model.addObject("user", user);
			model.setViewName("user-profile");
		
		return model;
	}
	
	/*
	 * controller for retrieve data that will be edit
	 * goes to edit form
	 * */
	@RequestMapping(value = "/profile-edit/{id}", method = RequestMethod.GET)
	public ModelAndView editUser(@PathVariable int id, ModelAndView model, HttpServletRequest request) {
		request.getSession(true);

        User listuser = userService.findUserById(id);
		
			model.addObject("user", listuser);
			model.setViewName("profile-edit");
		
		
		
		return model;
	}
	
	/*
	 * controller for collecting the edited data
	 * passed it to database
	 * goes back to dashboard
	 * */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updateUser(
			@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			@RequestParam("phonenumber") String phonenumber,@RequestParam("country") String country,
			@RequestParam("city") String city,@RequestParam("companyname") String companyname,
			@RequestParam("qualification") String qualification,@RequestParam("careerpath") String careerpath, 
			@RequestParam("userID") Integer userID) {

		User user = new User();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setPhonenumber(phonenumber);
		user.setCountry(country);
		user.setCity(city);
		user.setCompanyname(companyname);
		user.setQualification(qualification);
		user.setCareerpath(careerpath);
		user.setUserID(userID);
		userService.updateProfile(user);

		return new ModelAndView("redirect:/profile");
	}
	
	@RequestMapping("/searchuser")
    public String viewHomePage(Model model, @Param("keyword") String keyword) {
        List<User> listStore = userService.listAll(keyword);
        model.addAttribute("allStore", listStore);
        model.addAttribute("keyword", keyword);
         
        return "search-user";
    }
	
	@RequestMapping(value = "/otheruser/{id}", method = RequestMethod.GET)
	public ModelAndView seeOtherUser(@PathVariable int id, ModelAndView model, HttpServletRequest request) {
		request.getSession(true);

        User listuser = userService.findUserById(id);
		
			model.addObject("user", listuser);
			model.setViewName("other-user-profile");
		
		
		
		return model;
	}

}
