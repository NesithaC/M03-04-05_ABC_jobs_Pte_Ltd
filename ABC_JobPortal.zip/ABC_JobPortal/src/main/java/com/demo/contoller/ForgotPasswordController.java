package com.demo.contoller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.demo.model.User;
import com.demo.service.UserService;

public class ForgotPasswordController {
	
	@Autowired
	public UserService userService;
	
	@RequestMapping("/forgot-password")
	public ModelAndView forgotPassword() {
		ModelAndView mv = new ModelAndView();
		
		User user = new User();
		
		mv.setViewName("forgot-password");
		mv.addObject("forgotpassUser", user);
		return mv;
	}
	

}
