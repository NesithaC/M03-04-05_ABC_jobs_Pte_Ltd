package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.User;
import com.demo.model.UserDto;
import com.demo.repo.UserRepository;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.UserDao;

import com.demo.model.User;
import com.demo.model.UserDto;

import com.demo.repo.UserDtoRepository;
import com.demo.repo.UserRepository;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.UserDao;

import com.demo.model.User;
import com.demo.model.UserDto;

import com.demo.repo.UserDtoRepository;
import com.demo.repo.UserRepository;



import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.UserDao;

import com.demo.model.User;
import com.demo.model.UserDto;

import com.demo.repo.UserDtoRepository;
import com.demo.repo.UserRepository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.UserDao;

import com.demo.model.User;
import com.demo.model.UserDto;

import com.demo.repo.UserDtoRepository;
import com.demo.repo.UserRepository;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.model.BulkEmail;
import com.demo.model.User;
import com.demo.service.UserService;
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepo;
	
//	@Autowired
//	private UserDtoRepository userDtoRepo;


	public User register(User user) {
		return userRepo.save(user);
	}


	public User loginUser(UserDto loginDto) {
		User user = userRepo.findByEmailAndPass(loginDto.getEmailId(), loginDto.getPassword());
		System.out.println(user);
		if (user == null) {
			return null;
		}
		return user;
	}

	public void updateProfile(User user) {
		User newUser = userRepo.findByUserID(user.getUserID());
		newUser.setFirstName(user.getFirstName());
		newUser.setLastName(user.getLastName());
		newUser.setCountry(user.getCountry());
		newUser.setPhonenumber(user.getPhonenumber());
		newUser.setCity(user.getCity());
		newUser.setCompanyname(user.getCompanyname());
		newUser.setQualification(user.getQualification());
		newUser.setCareerpath(user.getCareerpath());
		userRepo.save(newUser);
	}
	public User findUserById(int id) {
		return userRepo.findByUserID(id);
	}
	
	public List<User> listAll() {
		return (List<User>) userRepo.findAll();
	}
	
	public User get(Long id) {
		return userRepo.findById(id).get();
	}
	
	public void delete(Integer id) {
		userRepo.deleteByUserID(id);
	}
	
	public List<User> listAll(String keyword) {
        if (keyword != null) {
            return userRepo.search(keyword);
        }
        return userRepo.findAll();
    }
	
	public List<User> findAllUser(){
		List<User> users = userRepo.findAll();
		return users;
	}
	
	public boolean deleteTest(Integer id) {
		try {
			
			userRepo.deleteByUserID(id);
			return true;
		}catch (Exception e) {
			System.out.println(e);
		}		
		return false;
	}
	
	public User updatePassword(String password, String email) {
		// TODO Auto-generated method stub
		return null;
	}


}
