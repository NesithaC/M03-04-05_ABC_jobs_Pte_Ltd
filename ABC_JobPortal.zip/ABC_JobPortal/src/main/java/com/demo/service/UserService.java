package com.demo.service;

import java.util.List;
import java.util.Optional;

import com.demo.model.User;
import com.demo.model.UserDto;

public interface UserService {
	
	public User register(User user);
	
	public User loginUser(UserDto loginDto);

	public void updateProfile(User user);

	public User findUserById(int id);
	
	public List<User> listAll();
	
	public User get(Long id);
	
	public void delete(Integer id);
	
	public List<User> listAll(String keyword);
	
	public List<User> findAllUser();
	
}
