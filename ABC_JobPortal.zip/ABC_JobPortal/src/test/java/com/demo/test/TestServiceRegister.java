package com.demo.test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ContextConfiguration;

import com.demo.config.ViewRes;
import com.demo.model.User;
import com.demo.repo.UserRepository;
import com.demo.service.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = {ViewRes.class})
public class TestServiceRegister {
	
	@InjectMocks
	UserServiceImpl userServiceImpl;
	
	@Mock
	UserRepository userRepo;
	
	@Test
	public void registerTest() {
		
		User user = new User();
		
		user.setFirstName("Testfirst");
		user.setLastName("Testlast");
		user.setEmail("testuser@example.com");
		user.setPass("TestUser");
		user.setPhonenumber("0000000");
		
		assertTrue(userServiceImpl.register(user));
	}

	private void assertTrue(User register) {
		// TODO Auto-generated method stub
		
	}

	

}
