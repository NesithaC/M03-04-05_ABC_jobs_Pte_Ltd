package com.demo.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ContextConfiguration;

import com.demo.config.ViewRes;
import com.demo.repo.UserRepository;
import com.demo.service.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = {ViewRes.class})
public class TestServiceDelete {
	
	@InjectMocks
	UserServiceImpl userServiceImpl;
	
	@Mock
	UserRepository userRepo;
	
	@Test
	public void deleteTest() {
		
		boolean delete = userServiceImpl.deleteTest(1);
		assertTrue(delete);
		
	}
	

}

