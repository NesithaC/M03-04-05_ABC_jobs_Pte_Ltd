package com.demo.test;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ContextConfiguration;

import com.demo.config.ViewRes;
import com.demo.model.User;
import com.demo.repo.UserRepository;
import com.demo.service.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = {ViewRes.class})
public class TestServicePassword {
	
	@InjectMocks
	UserServiceImpl userServiceImpl;
	
	@Mock
	UserRepository userRepo;
	
	@Test
	public void updatePasswordTest() {
		
		String email = "nesitha@gmail.com";
		String password = "NewTest";
		
		assertTrue(userServiceImpl.updatePassword(password, email));
	}

	private void assertTrue(User updatePassword) {
		// TODO Auto-generated method stub
		
	}

}

